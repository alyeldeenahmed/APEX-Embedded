Start with 00_Start_Here.pdf. Each component has its own guide.
CSV files contain headers only: no measurements have been invented.
Interface review is complete on Embedded side; peer decisions are listed in 01_Interface_Review.pdf.
Do not enable vehicle outputs using placeholder calibration.
